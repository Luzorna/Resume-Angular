export class Skill {
    id: number= 0;
    label:string = '';
    rating:number = 0;
}
